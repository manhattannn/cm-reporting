/*
 * tabs_core.js
 */
var el;

(function($) {

module("tabs: core");

})(jQuery);
